import{x as a}from"./Cgqc9acl.js";a();
